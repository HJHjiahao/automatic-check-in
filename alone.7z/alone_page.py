from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtGui import QIntValidator
from PyQt5.QtCore import QThread

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import os
import pandas as pd
import random

random.seed(2021)


class Ui_MainWindow(QMainWindow):
    def setupUi(self, ):
        self.setObjectName("MainWindow")
        self.resize(800, 600)
        self.setMinimumSize(QtCore.QSize(800, 600))
        self.setMaximumSize(QtCore.QSize(800, 600))
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")

        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(220, 150, 180, 60))
        self.label.setStyleSheet("font: 75 11pt \"微软雅黑\";\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba("
                                 "255, 255, 255, 255), stop:1 rgba(162, 187, 255, 255));")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(220, 250, 180, 60))
        self.label_2.setStyleSheet("font: 75 11pt \"微软雅黑\";\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, "
                                   "stop:0 rgba(255, 255, 255, 255), stop:1 rgba(162, 187, 255, 255));")
        self.label_2.setObjectName("label_2")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(220, 50, 180, 60))
        self.label_5.setStyleSheet("font: 75 11pt \"微软雅黑\";\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, "
                                   "stop:0 rgba(255, 255, 255, 255), stop:1 rgba(162, 187, 255, 255));")
        self.label_5.setObjectName("label_5")

        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(400, 150, 180, 60))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(400, 250, 180, 60))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_3.setGeometry(QtCore.QRect(400, 50, 180, 60))
        self.lineEdit_3.setObjectName("lineEdit_2")

        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(220, 500, 180, 60))
        self.label_3.setStyleSheet("font: 75 11pt \"微软雅黑\";\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, "
                                   "stop:0 rgba(255, 255, 255, 255), stop:1 rgba(162, 187, 255, 255));")
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(400, 500, 180, 60))
        self.label_4.setStyleSheet("font: 75 11pt \"微软雅黑\";\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, "
                                   "stop:0 rgba(255, 255, 255, 255), stop:1 rgba(162, 187, 255, 255));")
        self.label_4.setObjectName("label_4")

        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(220, 400, 180, 60))
        self.pushButton.setStyleSheet("font: 75 11pt \"微软雅黑\";\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, "
                                      "stop:0 rgba(255, 255, 255, 255), stop:1 rgba(162, 187, 255, 255));")

        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(400, 400, 180, 60))
        self.pushButton_2.setStyleSheet("font: 75 11pt \"微软雅黑\";\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, "
                                        "stop:0 rgba(255, 255, 255, 255), stop:1 rgba(162, 187, 255, 255));")

        self.pushButton_2.setObjectName("pushButton_2")

        self.setCentralWidget(self.centralwidget)

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

    def retranslateUi(self, ):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("MainWindow", "For_NEUer"))
        self.label.setText(_translate("MainWindow", "       学号"))
        self.label_2.setText(_translate("MainWindow", "       密码"))
        self.label_3.setText(_translate("MainWindow", "    打卡情况"))
        self.label_4.setText(_translate("MainWindow", "    备案情况"))
        self.label_5.setText(_translate("MainWindow", "   driver路径"))
        self.pushButton.setText(_translate("MainWindow", "健康要打卡"))
        self.pushButton_2.setText(_translate("MainWindow", "出入校备案"))


class Alone_Page(Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.correct = './correct.xlsx'
        self.setupUi()
        self.recording()

        self.lineEdit.setValidator(QIntValidator())
        self.pushButton.clicked.connect(self.clo)
        self.pushButton_2.clicked.connect(self.fil)

    def recording(self):
        if not os.path.exists(self.correct):
            df = pd.DataFrame(columns=['student_id', 'password', 'time', 'path'])
            df.to_excel(self.correct, index=False)
        excel = pd.ExcelFile(self.correct)
        df = excel.parse(excel.sheet_names[0])
        current = df.shape[0]
        if current > 0:
            info = df.values[0].tolist()
            self.lineEdit.setText(str(info[0]))
            self.lineEdit_2.setText(str(info[1]))
            self.lineEdit_3.setText(str(info[3]))

    def clo(self):
        account = str(self.lineEdit.text())
        password = str(self.lineEdit_2.text())
        driver_path = str(self.lineEdit_3.text())
        if account == '':
            self.label_3.setText('    账号为空')
            return
        if password == '':
            self.label_3.setText('    密码为空')
            return
        if driver_path == '':
            self.label_3.setText('    路径为空')
            return
        self.label_3.setText('    打卡中..')
        self.work = WorkThread(choice=1, account=account, password=password,
                               label=self.label_3,
                               driver_path=driver_path, file=self.correct)
        self.work.start()

    def fil(self):
        account = str(self.lineEdit.text())
        password = str(self.lineEdit_2.text())
        driver_path = str(self.lineEdit_3.text())
        if account == '':
            self.label_4.setText('    账号为空')
            return
        if password == '':
            self.label_4.setText('    密码为空')
            return
        if driver_path == '':
            self.label_4.setText('    路径为空')
            return
        self.label_4.setText('    备案中..')
        sites = ['白塔', '全运路', '万达', '奥体', '青年大街']
        site = sites[random.randrange(0, len(sites))]
        self.work = WorkThread(choice=2, account=account, password=password,
                               label=self.label_4,
                               file=self.correct, driver_path=driver_path, site=site)
        self.work.start()


class WorkThread(QThread):
    def __init__(self, choice, account, password, label, file, driver_path, site=''):
        super().__init__()
        self.choice = choice
        self.account = account
        self.password = password
        self.label = label
        self.file = file
        self.driver = driver_path
        self.site = site

    def run(self):
        if self.choice == 1:
            self.clock_in()
        if self.choice == 2:
            self.submit_file()

    def clock_in(self,):
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        # chrome_options.add_argument('--disable-gpu')
        driver = webdriver.Chrome(self.driver, options=chrome_options)

        driver.get('https://ehall.neu.edu.cn/db_portal/guide?id=D06BDA87-2E6E-4324-A14D-3BFAD839F2B9')
        time.sleep(3 * random.random())
        driver.maximize_window()

        driver.find_element_by_css_selector('input[value="我要办理"]').click()
        time.sleep(5 * random.random())
        driver.switch_to.window(driver.window_handles[-1])
        id_input = driver.find_element_by_id('un')
        pd_input = driver.find_element_by_id('pd')
        id_input.send_keys(self.account)
        pd_input.send_keys(self.password)
        driver.find_element_by_id('index_login_btn').click()
        if 'https://pass.neu.edu.cn/tpass/login' in driver.current_url:
            self.label.setText('多次错误将锁死')
            return
        time.sleep(5 * random.random())

        driver.find_element_by_xpath('//*[@id="app"]/main/div/form/div[1]/table/tbody/tr/td[1]/div/div/div/label[1]') \
            .click()
        time.sleep(2 * random.random())
        driver.find_element_by_xpath(
            '//*[@id="app"]/main/div/form/div[3]/div[2]/table/tbody/tr[1]/td/div/div/div/label[1]') \
            .click()
        time.sleep(2 * random.random())
        driver.find_element_by_xpath(
            '//*[@id="app"]/main/div/form/div[4]/div[2]/table/tbody/tr[1]/td/div/div/div/label[1]') \
            .click()

        time.sleep(3 * random.random())
        driver.find_element_by_css_selector('button[type="button"][class="el-button el-button--primary"]').click()
        self.label.setText('    打卡成功')
        new = []
        new.append(str(self.account))
        new.append(str(self.password))
        new.append('打卡 ' + time.strftime('%Y%m%d %H:%M:%S', time.localtime()))
        new.append(self.driver)
        excel = pd.ExcelFile(self.file)
        df = excel.parse(excel.sheet_names[0])
        current = df.shape[0]
        df.loc[current] = new
        df.to_excel(self.file, index=False)
        driver.quit()

    def submit_file(self, ):
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        driver = webdriver.Chrome(self.driver, options=chrome_options)

        driver.get('https://ehall.neu.edu.cn/db_portal/guide?id=DBEB1E6B-F131-45FE-B7CB-A183AD521912')
        time.sleep(3 * random.random())
        driver.maximize_window()

        driver.find_element_by_css_selector('input[value="我要办理"]').click()
        time.sleep(5 * random.random())
        driver.switch_to.window(driver.window_handles[-1])

        driver.find_element_by_id('un').send_keys(self.account)
        driver.find_element_by_id('pd').send_keys(self.password)
        driver.find_element_by_id('index_login_btn').click()
        if 'https://pass.neu.edu.cn/tpass/login' in driver.current_url:
            self.label.setText('多次错误将锁死')
            return
        time.sleep(5)
        hms = time.strftime('%H:%M', time.localtime())
        x = random.randrange(2, 4)
        future = str(int(hms[0:2]) + x) + ':' + '35'
        driver.find_element_by_xpath('//*[@id="V1_CTRL80"]').send_keys(hms)
        time.sleep(2 * random.random())
        driver.find_element_by_xpath('//*[@id="V1_CTRL82"]').send_keys(future)
        time.sleep(2 * random.random())
        driver.find_element_by_xpath('//*[@id="V1_CTRL92_0"]').send_keys(self.site)
        time.sleep(3 * random.random())
        buttons = driver.find_elements_by_css_selector('a[class="command_button_content"]')
        buttons[1].click()
        time.sleep(3 * random.random())
        driver.find_element_by_css_selector('button[class="dialog_button default rightest fr"]').click()
        time.sleep(3 * random.random())
        driver.find_element_by_css_selector('button[class="dialog_button default rightest fr"]').click()
        self.label.setText('    备案成功')
        new = []
        new.append(str(self.account))
        new.append(str(self.password))
        new.append('备案 ' + time.strftime('%Y%m%d %H:%M:%S', time.localtime()))
        new.append(self.driver)
        excel = pd.ExcelFile(self.file)
        df = excel.parse(excel.sheet_names[0])
        current = df.shape[0]
        df.loc[current] = new
        df.to_excel(self.file, index=False)
        driver.quit()
