from PyQt5 import QtWidgets
import sys
#from web.alone.alone_page import Alone_Page
from alone_page import Alone_Page

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    page = Alone_Page()
    page.show()
    sys.exit(app.exec_())
